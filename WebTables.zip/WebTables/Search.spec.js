// tests/Text Box.spec.js
import { test, expect } from '@playwright/test';

test.describe('DemoQA Elements Tests', () => {
  
  // 4. Web Tables Test
  test('Search', async ({ page }) => {
    await page.goto('https://demoqa.com/');
    await page.waitForTimeout(2000); 

     //click element button
    await page.click("//div[@class='category-cards']//div[1]//div[1]//div[2]//*[name()='svg']");

    await page.click("//div[@class='element-list collapse show']//li[@id='item-3']", { waitUntil: 'domcontentloaded' });
    
    // === Search for the Added Record ===
    await page.fill('#searchBox', 'Cierra');
    //await expect(page.locator('td')).toContainText('Huda');
    await page.waitForTimeout(2000);
  });

}); 
