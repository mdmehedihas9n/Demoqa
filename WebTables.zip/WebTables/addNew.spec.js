// tests/Text Box.spec.js
import { test, expect } from '@playwright/test';

test.describe('DemoQA Elements Tests', () => {
  
  // 4. Web Tables Test
  test('WebTables Box test', async ({ page }) => {

    await page.goto("https://demoqa.com/");
    await page.waitForTimeout(2000); 

     //click element button
     await page.click("//div[@class='category-cards']//div[1]//div[1]//div[2]//*[name()='svg']");

     await page.click("//div[@class='element-list collapse show']//li[@id='item-3']", { waitUntil: 'domcontentloaded' });
    
     // Click to add a new record
     await page.click('#addNewRecordButton');
     await page.fill('#firstName', 'Huda');
     await page.fill('#lastName', 'Don');
     await page.fill('#userEmail', 'hudadon@gmail.com');
     await page.fill('#age', '25');
     await page.fill('#salary', '20000');
     await page.fill('#department', 'Software');
     await page.click('#submit');

    
     // Check if the new record appears in the table
     //await expect(page.locator('.rt-tbody')).toContainText('hudadon@gmail.com');
     //await page.waitForTimeout(5000);

  });

}); 
