// tests/Text Box.spec.js
import { test, expect } from '@playwright/test';

test.describe('DemoQA Elements Tests', () => {
  
  // 4. Web Tables Test
  test('Edit', async ({ page }) => {
    await page.goto('https://demoqa.com/');
    await page.waitForTimeout(2000); 

     //click element button
    await page.click("//div[@class='category-cards']//div[1]//div[1]//div[2]//*[name()='svg']");

    await page.click("//div[@class='element-list collapse show']//li[@id='item-3']", { waitUntil: 'domcontentloaded' });
    
    // === Edit the Record ===
    await page.click('span[title="Edit"]'); // Click Edit (Pencil Icon)
    await page.fill('#age', '30'); // Update Age
    await page.click('#submit');

    // Verify the update
    //await expect(page.locator('td')).toContainText('30');
    await page.waitForTimeout(2000);

  });

}); 
