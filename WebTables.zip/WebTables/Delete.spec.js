// tests/Text Box.spec.js
import { test, expect } from '@playwright/test';

test.describe('DemoQA Elements Tests', () => {
  
  // 4. Web Tables Test
  test('Delete', async ({ page }) => {
    await page.goto('https://demoqa.com/');
    await page.waitForTimeout(2000); 

     //click element button
    await page.click("//div[@class='category-cards']//div[1]//div[1]//div[2]//*[name()='svg']");

    await page.click("//div[@class='element-list collapse show']//li[@id='item-3']", { waitUntil: 'domcontentloaded' });
    
    // === Delete the Record ===
    await page.click('span[title="Delete"]'); // Click Delete (Trash Icon)

    // Verify Deletion
    await page.fill('#searchBox', 'Cierra'); // Search again
    //await expect(page.locator('.rt-tbody')).not.toContainText('Cierra'); // Ensure it's gone
    await page.waitForTimeout(2000);
  });

}); 
